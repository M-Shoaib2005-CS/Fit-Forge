using FitForge.BL;
using FitForge.DL;
using FitForge.Models;
using FitForge.Services;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Text.Json;

namespace FitForge.Controllers
{
    public class ChatTurnDto { public string Role { get; set; } = "user"; public string Text { get; set; } = ""; }
    public class ChatReq { public List<ChatTurnDto> History { get; set; } = new(); }
    public class DayPickReq { public int DayId { get; set; } public int ExerciseId { get; set; } }
    public class ResolveSuggestionReq { public int SuggestionId { get; set; } public List<int> DayIds { get; set; } = new(); public List<DayPickReq> Picks { get; set; } = new(); }

    public class CoachController(GeminiService gemini, ProgramBL programBL, ProfileBL profileBL, InjuryDL injuryDL, UserDL uDL, MeasurementDL measDL, RecoveryCoachingBL rcBL) : BaseController(uDL)
    {
        [HttpGet]
        public IActionResult GetPendingSuggestion()
        {
            if (Uid == null) return Json(new { hasPending = false });
            var s = rcBL.GetPending(Uid.Value);
            if (s == null) return Json(new { hasPending = false });
            return Json(new { hasPending = true, view = rcBL.BuildSuggestionView(s) });
        }

        [HttpPost, IgnoreAntiforgeryToken]
        public IActionResult ResolveSuggestion([FromBody] ResolveSuggestionReq req)
        {
            if (Uid == null) return Json(new { success = false, msg = "Please log in first." });
            try
            {
                var acceptedDays = new Dictionary<int, int?>();
                foreach (var dayId in req.DayIds)
                {
                    var pick = req.Picks.FirstOrDefault(p => p.DayId == dayId);
                    acceptedDays[dayId] = pick != null ? pick.ExerciseId : (int?)null;
                }
                rcBL.Resolve(Uid.Value, req.SuggestionId, acceptedDays);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, msg = "Couldn't update that: " + ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Chat([FromBody] ChatReq req)
        {
            if (Uid == null) return Json(new { kind = "chat", message = "Please log in first." });
            if (req.History == null || req.History.Count == 0)
                return Json(new { kind = "chat", message = "Say something and I'll help out." });

            var turns = req.History.Select(h => new CoachTurn { Role = h.Role, Text = h.Text }).ToList();

            // Give the coach real, current knowledge of this specific user's injuries — the app
            // already tracks which exercises are flagged risky per active injury (used elsewhere
            // for workout logging); the coach should respect the exact same data when proposing
            // programs, not just rely on whatever was said earlier in this one conversation.
            string? userContext = null;
            var currentUser = uDL.GetById(Uid.Value);
            if (currentUser != null && !string.IsNullOrWhiteSpace(currentUser.CoachName) && currentUser.CoachName != "Coach")
            {
                userContext = $"This user has named you '{currentUser.CoachName}'. Respond to that name if asked what you're called, and sign off in that persona — you're still the same in-app coach otherwise.";
            }

            // Only pass along what the user actually logged — no defaults, no
            // assuming a value because a field exists on the model. This lets
            // the coach give genuinely tailored suggestions (recovery capacity,
            // load progression, rough nutrition ballpark) without ever having
            // to ask the basics first.
            if (currentUser != null)
            {
                var stats = new List<string>();
                if (currentUser.Age > 0) stats.Add($"age {currentUser.Age}");
                if (!string.IsNullOrWhiteSpace(currentUser.Gender)) stats.Add(currentUser.Gender);
                if (currentUser.Height > 0) stats.Add($"height {currentUser.Height}cm");
                if (currentUser.Weight > 0) stats.Add($"weight {currentUser.Weight}kg");
                if (currentUser.Height > 0 && currentUser.Weight > 0) stats.Add($"BMI {currentUser.BMI} ({currentUser.BMICat})");
                if (!string.IsNullOrWhiteSpace(currentUser.FitnessLevel)) stats.Add($"self-reported fitness level: {currentUser.FitnessLevel}");

                if (stats.Count > 0)
                {
                    string bodyContext = "This user's logged body stats — use them silently to tailor suggestions (don't recite these numbers back unless the user specifically asks about them or it's directly relevant to explain a recommendation). Never diagnose, give medical advice, or comment on appearance: " + string.Join(", ", stats) + ".";
                    userContext = userContext == null ? bodyContext : userContext + " " + bodyContext;
                }

                var latest = measDL.GetLatest(Uid.Value);
                if (latest != null)
                {
                    var m = new List<string>();
                    if (latest.ChestCm.HasValue) m.Add($"chest {latest.ChestCm}cm");
                    if (latest.WaistCm.HasValue) m.Add($"waist {latest.WaistCm}cm");
                    if (latest.HipsCm.HasValue) m.Add($"hips {latest.HipsCm}cm");
                    if (latest.ShouldersCm.HasValue) m.Add($"shoulders {latest.ShouldersCm}cm");
                    if (latest.NeckCm.HasValue) m.Add($"neck {latest.NeckCm}cm");
                    if (latest.LeftArmCm.HasValue || latest.RightArmCm.HasValue) m.Add($"arms L{latest.LeftArmCm}/R{latest.RightArmCm}cm");
                    if (latest.LeftThighCm.HasValue || latest.RightThighCm.HasValue) m.Add($"thighs L{latest.LeftThighCm}/R{latest.RightThighCm}cm");
                    if (latest.BodyFatPct.HasValue) m.Add($"body fat {latest.BodyFatPct}%");

                    if (m.Count > 0)
                    {
                        string measureContext = $"Most recent body measurements logged ({latest.RecordedAt:MMM d}, use silently, don't recite unless asked): " + string.Join(", ", m) + ".";
                        userContext = userContext == null ? measureContext : userContext + " " + measureContext;
                    }
                }
            }
            try
            {
                var activeInjuries = injuryDL.GetActiveForUser(Uid.Value);
                if (activeInjuries.Count > 0)
                {
                    var flagged = injuryDL.GetFlaggedExercises(Uid.Value);
                    string injuryList = string.Join("; ", activeInjuries.Select(i => $"{i.BodyPart} ({i.Category})"));
                    string flagList = flagged.Count > 0
                        ? string.Join("; ", flagged.Select(f => $"#{f.ExerciseId} {f.ExerciseName}" +
                            (f.AlternativeId.HasValue ? $" → use #{f.AlternativeId} {f.AlternativeName} instead" : " → avoid, pick a different catalog exercise")))
                        : "none of the catalog exercises are specifically flagged, but use judgment around the affected area";
                    string injuryContext = $"Active injuries logged for this user: {injuryList}. Exercises flagged risky given those injuries: {flagList}.";
                    userContext = userContext == null ? injuryContext : userContext + " " + injuryContext;
                }
            }
            catch (Exception ex)
            {
                // Never let a lookup failure block the chat entirely — just proceed without
                // injury context for this turn rather than erroring out the whole request.
                _ = ex;
            }

            var reply = await gemini.SendAsync(turns, userContext);

            // Safety net: if the model claimed a proposal but the program object didn't actually
            // come back with real day/exercise content (schema drift, truncation, etc.), don't let
            // a confusing "here's your program!" message reach the user with nothing to tap.
            if (reply.Kind == "proposal" && !GeminiService.HasUsableProgram(reply.Program))
            {
                return Json(new
                {
                    kind = "chat",
                    message = "Sorry — I put that program together but it didn't come through properly. Mind trying again, maybe with a bit less detail in one message?",
                    quickReplies = Array.Empty<string>(),
                    program = (object?)null,
                    injury = (object?)null
                });
            }

            // The model's own chat message might claim an injury has been "logged" the moment it
            // has enough detail — so rather than requiring a separate, easy-to-miss button tap to
            // actually make that true, we log it for real right here, server-side, and let our own
            // deterministic message (not the model's) reflect what actually happened in the DB.
            if (reply.Kind == "injury_report")
            {
                var (logged, resultMessage, resolvedInjury) = TryLogInjury(Uid.Value, reply.Injury);
                return Json(new
                {
                    kind = logged ? "injury_logged" : "question",
                    message = resultMessage,
                    quickReplies = Array.Empty<string>(),
                    program = (object?)null,
                    injury = resolvedInjury
                });
            }

            if (reply.Kind == "injury_resolved")
            {
                var (resolved, resultMessage, closedInjury) = TryResolveInjury(Uid.Value, reply.Injury);
                return Json(new
                {
                    kind = resolved ? "injury_resolved" : "question",
                    message = resultMessage,
                    quickReplies = Array.Empty<string>(),
                    program = (object?)null,
                    injury = closedInjury
                });
            }

            return Json(new
            {
                kind = reply.Kind,
                message = reply.Message,
                quickReplies = reply.QuickReplies,
                program = reply.Program,
                injury = reply.Injury
            });
        }

        // Resolves the model's plain-text bodyPart/category (from the fixed catalogs baked into
        // the system prompt) into real DB ids and logs it immediately — same effect as the manual
        // Profile > Injuries flow. Returns a message grounded in what actually happened, never in
        // what the model merely said.
        private (bool logged, string message, object? injury) TryLogInjury(int uid, JsonElement? injuryEl)
        {
            if (injuryEl == null || injuryEl.Value.ValueKind != JsonValueKind.Object)
                return (false, "Which body part is it, and is it more of a muscle pull/strain or joint pain/stiffness?", null);

            string bodyPart = Get(injuryEl.Value, "bodyPart");
            string category = Get(injuryEl.Value, "category");
            string notes    = Get(injuryEl.Value, "notes");

            var part = injuryDL.GetBodyParts()
                .FirstOrDefault(p => string.Equals(p.Name, bodyPart, StringComparison.OrdinalIgnoreCase));
            var cat = injuryDL.GetCategories()
                .FirstOrDefault(c => string.Equals(c.Name, category, StringComparison.OrdinalIgnoreCase));

            if (part == null || cat == null)
                return (false, "I want to make sure I flag the right thing — which body part is it exactly, and is it more of a muscle pull/strain or joint pain/stiffness?", null);

            var (ok, _) = profileBL.LogInjury(uid, new LogInjuryReq { PartId = part.PartId, CategoryId = cat.CategoryId, Notes = notes });
            if (!ok)
                return (false, "Sorry, something went wrong logging that — mind trying again?", null);

            string msg = $"Logged — {part.Name} ({cat.Name}). I'll flag any exercises that could aggravate it in your workouts.";
            return (true, msg, new { bodyPart = part.Name, category = cat.Name, notes });
        }

        // Matches the model's bodyPart/category against this user's actual active
        // injuries (not just the catalogs — an injury only resolves if it's really
        // logged as active for this user) and closes the matching one out. Same
        // "trust the DB, not the model's claim" principle as TryLogInjury above.
        private (bool resolved, string message, object? injury) TryResolveInjury(int uid, JsonElement? injuryEl)
        {
            if (injuryEl == null || injuryEl.Value.ValueKind != JsonValueKind.Object)
                return (false, "Which injury do you mean?", null);

            string bodyPart = Get(injuryEl.Value, "bodyPart");
            string category = Get(injuryEl.Value, "category");

            var active = injuryDL.GetActiveForUser(uid)
                .FirstOrDefault(i => string.Equals(i.BodyPart, bodyPart, StringComparison.OrdinalIgnoreCase)
                                   && string.Equals(i.Category, category, StringComparison.OrdinalIgnoreCase));

            if (active == null)
                return (false, "I couldn't find that as one of your currently active injuries — which one do you mean?", null);

            bool ok = profileBL.ResolveInjury(uid, active.UiId);
            if (!ok)
                return (false, "Sorry, something went wrong updating that — mind trying again?", null);

            string msg = $"Nice — marked {active.BodyPart} ({active.Category}) as resolved. I won't flag exercises for it anymore.";
            return (true, msg, new { bodyPart = active.BodyPart, category = active.Category });
        }

        [HttpPost]
        public IActionResult ApplyProgram([FromBody] JsonElement programJson)
        {
            if (Uid == null) return Json(new { success = false, msg = "Please log in first." });
            try
            {
                var req = new CreateProgramReq
                {
                    Name = Get(programJson, "name"),
                    Description = Get(programJson, "description"),
                    GoalType = OrDefault(Get(programJson, "goalType"), "General"),
                    ProgressionStyle = OrDefault(Get(programJson, "progressionStyle"), "Adaptive"),
                    Days = new List<DayReq>()
                };

                if (programJson.TryGetProperty("days", out var daysEl) && daysEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var d in daysEl.EnumerateArray())
                    {
                        var day = new DayReq
                        {
                            Name = Get(d, "name"),
                            DayType = OrDefault(Get(d, "dayType"), "Workout"),
                            Exercises = new List<ExerciseReq>()
                        };
                        if (d.TryGetProperty("exercises", out var exEl) && exEl.ValueKind == JsonValueKind.Array)
                        {
                            foreach (var e in exEl.EnumerateArray())
                            {
                                day.Exercises.Add(new ExerciseReq
                                {
                                    ExerciseId  = e.TryGetProperty("exerciseId", out var eid) ? eid.GetInt32() : 0,
                                    Sets        = e.TryGetProperty("sets", out var s) ? s.GetInt32() : 3,
                                    Reps        = e.TryGetProperty("reps", out var r) ? r.GetInt32() : 10,
                                    WeightKg    = e.TryGetProperty("weightKg", out var w) && w.ValueKind == JsonValueKind.Number ? w.GetDouble() : (double?)null,
                                    RestSeconds = e.TryGetProperty("restSeconds", out var rs) ? rs.GetInt32() : 90
                                });
                            }
                        }
                        req.Days.Add(day);
                    }
                }

                // autoSchedule:true — a program the coach hands over should show up on the
                // week immediately, not just sit unassigned in the Programs list.
                var (ok, msg, programId) = programBL.CreateProgram(Uid.Value, req, autoSchedule: true);
                return Json(new { success = ok, msg, programId });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, msg = "Couldn't create that program: " + ex.Message });
            }
        }

        // Kept for manual/API use — the coach's own chat flow now logs injuries automatically via
        // TryLogInjury above, but this endpoint still works standalone if ever needed.
        [HttpPost]
        public IActionResult LogInjury([FromBody] JsonElement injuryJson)
        {
            if (Uid == null) return Json(new { success = false, msg = "Please log in first." });
            try
            {
                string bodyPart = Get(injuryJson, "bodyPart");
                string category = Get(injuryJson, "category");
                string notes    = Get(injuryJson, "notes");

                var part = injuryDL.GetBodyParts()
                    .FirstOrDefault(p => string.Equals(p.Name, bodyPart, StringComparison.OrdinalIgnoreCase));
                var cat = injuryDL.GetCategories()
                    .FirstOrDefault(c => string.Equals(c.Name, category, StringComparison.OrdinalIgnoreCase));

                if (part == null || cat == null)
                    return Json(new { success = false, msg = "Couldn't match that to a known body part / injury type." });

                var (ok, msg) = profileBL.LogInjury(Uid.Value, new LogInjuryReq
                {
                    PartId = part.PartId,
                    CategoryId = cat.CategoryId,
                    Notes = notes
                });
                return Json(new { success = ok, msg });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, msg = "Couldn't log that injury: " + ex.Message });
            }
        }

        private static string Get(JsonElement el, string prop) =>
            el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
        private static string OrDefault(string v, string fallback) => string.IsNullOrWhiteSpace(v) ? fallback : v;
    }
}
