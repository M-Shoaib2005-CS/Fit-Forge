using Microsoft.Extensions.Logging;
using FitForge.DL;
using FitForge.Models;
using System.Text.Json;

namespace FitForge.BL
{
    // Recovery-aware volume coaching: detects when a user is consistently doing
    // far less (or far more) than their programmed volume and produces a
    // concrete, deterministic suggestion. Every number and exercise choice here
    // is computed in C# — Gemini's only job (elsewhere, in GeminiService/
    // CoachController) is to phrase the resulting payload into a message; it
    // never generates the detection or the specific changes itself.
    public class RecoveryCoachingBL(RecoveryCoachingDL rcDL, ILogger<RecoveryCoachingBL> log)
    {
        private const double LowThreshold = 0.5;   // < 50% of scheduled volume
        private const double HighThreshold = 2.0;  // > 200% of scheduled volume
        private const int RecencyDays = 20;         // ignore occurrences older than this when checking a day's last-2
        private const int CooldownDays = 14;

        public CoachSuggestionModel? GetPending(int uid) => rcDL.GetPendingSuggestion(uid);

        // Call once per finished session, after sets are persisted. Logs the
        // volume ratio, then runs detection. Returns true if a new suggestion
        // was created (caller can use this to badge the coach icon).
        public bool RecordSessionAndDetect(int uid, int sessionId, int dayId, List<LoggedSet> sets)
        {
            int setsCompleted = sets
                .Where(s => !s.Skipped && s.SetType != "Warmup")
                .Select(s => (s.PdeId, s.SetNumber))
                .Distinct()
                .Count();
            int setsScheduled = rcDL.GetScheduledSetsForDay(dayId);
            if (setsScheduled <= 0) return false; // nothing to compare against

            rcDL.LogVolume(uid, sessionId, dayId, setsCompleted, setsScheduled);

            // Only one suggestion is ever pending at a time — don't pile another
            // on top while the user hasn't responded to the last one.
            if (rcDL.GetPendingSuggestion(uid) != null) return false;

            return Detect(uid, dayId);
        }

        private bool Detect(int uid, int dayId)
        {
            // ── Whole-program check: last 3 sessions overall, any days, all
            //    the same direction (all low or all high), within recency. ──
            var recentOverall = rcDL.GetRecentOverall(uid, 3);
            if (recentOverall.Count == 3)
            {
                var cutoff = DateTime.Now.AddDays(-RecencyDays);
                bool allRecent = recentOverall.All(l => l.LoggedAt >= cutoff);
                bool allLow = recentOverall.All(l => l.IsLow);
                bool allHigh = recentOverall.All(l => l.IsHigh);
                if (allRecent && (allLow || allHigh))
                {
                    CreateWholeProgramSuggestion(uid, allLow ? "low" : "high");
                    return true;
                }
            }

            // ── Per-day anchor check: does THIS day's last 2 occurrences (within
            //    recency, since its own cooldown reset) both go the same way? ──
            var recentForDay = rcDL.GetRecentForDay(uid, dayId, 2);
            if (recentForDay.Count < 2) return false;
            var cutoff2 = DateTime.Now.AddDays(-RecencyDays);
            if (!recentForDay.All(l => l.LoggedAt >= cutoff2)) return false;

            bool anchorLow = recentForDay.All(l => l.IsLow);
            bool anchorHigh = recentForDay.All(l => l.IsHigh);
            if (!anchorLow && !anchorHigh) return false;

            string reason = anchorLow ? "low" : "high";
            var anchorOldest = recentForDay.Min(l => l.LoggedAt);
            var anchorNewest = recentForDay.Max(l => l.LoggedAt);

            // Bundle in any OTHER day-type that also had a hit in the same
            // direction somewhere between the anchor's two occurrences.
            var windowLogs = rcDL.GetRecentOverall(uid, 20)
                .Where(l => l.LoggedAt > anchorOldest && l.LoggedAt < anchorNewest && l.DayId != dayId)
                .Where(l => reason == "low" ? l.IsLow : l.IsHigh)
                .GroupBy(l => l.DayId)
                .Select(g => g.First())
                .ToList();

            CreateDaySuggestion(uid, dayId, reason, windowLogs.Select(l => l.DayId).ToList());
            return true;
        }

        private void CreateDaySuggestion(int uid, int anchorDayId, string reason, List<int> bundledDayIds)
        {
            var payload = new SuggestionPayload();
            payload.Days.Add(BuildSuggestionDay(anchorDayId, reason, isAnchor: true));
            foreach (var bId in bundledDayIds)
                payload.Days.Add(BuildSuggestionDay(bId, reason, isAnchor: false));

            var json = JsonSerializer.Serialize(payload);
            rcDL.CreateSuggestion(uid, reason == "low" ? "day_fix" : "add_exercise", json);
        }

        private void CreateWholeProgramSuggestion(int uid, string reason)
        {
            var dayIds = rcDL.GetActiveScheduleDayIds(uid);
            var payload = new SuggestionPayload();
            foreach (var dId in dayIds)
                payload.Days.Add(BuildSuggestionDay(dId, reason, isAnchor: true));

            var json = JsonSerializer.Serialize(payload);
            rcDL.CreateSuggestion(uid, "whole_program_fix", json);
        }

        private SuggestionDay BuildSuggestionDay(int dayId, string reason, bool isAnchor)
        {
            var day = new SuggestionDay
            {
                DayId = dayId,
                DayName = rcDL.GetDayName(dayId),
                IsAnchor = isAnchor,
                Reason = reason
            };

            var exercises = rcDL.GetDayExercisesForCoaching(dayId);

            if (reason == "low")
            {
                // Prefer trimming isolation work before compound work. Among
                // isolation exercises, cut the one carrying the most sets first;
                // drop it entirely if it's already down to 1-2 sets, otherwise
                // just remove one set. Falls back to a compound exercise only
                // if the day has no isolation work to trim at all.
                var pool = exercises.Where(e => e.IsCompound == false).OrderByDescending(e => e.TargetSets).ToList();
                if (pool.Count == 0) pool = exercises.OrderByDescending(e => e.TargetSets).ToList();

                if (pool.Count > 0)
                {
                    var target = pool[0];
                    if (target.TargetSets <= 2)
                        day.Changes.Add(new SuggestedChange { PdeId = target.PdeId, ExerciseName = target.Name, Action = "remove_exercise" });
                    else
                        day.Changes.Add(new SuggestedChange { PdeId = target.PdeId, ExerciseName = target.Name, Action = "cut_set", NewTargetSets = target.TargetSets - 1 });
                }
            }
            else // high — suggest adding an exercise, candidates from muscle groups already on the day
            {
                var muscleGroups = exercises.Select(e => e.MuscleGroup).Distinct().ToList();
                day.Candidates = rcDL.GetAddCandidates(dayId, muscleGroups, 4);
            }

            return day;
        }

        // ── Resolving a suggestion ──────────────────────────────────
        // acceptedDays: dayId -> picked exerciseId (only present/used for
        // "high" reason days, where the user chose one of the candidate pills).
        public void Resolve(int uid, int suggestionId, Dictionary<int, int?> acceptedDays)
        {
            var suggestion = rcDL.GetPendingSuggestion(uid);
            if (suggestion == null || suggestion.SuggestionId != suggestionId) return;

            var payload = JsonSerializer.Deserialize<SuggestionPayload>(suggestion.Payload) ?? new SuggestionPayload();

            foreach (var day in payload.Days)
            {
                bool accepted = acceptedDays.ContainsKey(day.DayId);
                if (accepted)
                {
                    if (day.Reason == "low")
                    {
                        foreach (var change in day.Changes) rcDL.ApplyChange(change);
                    }
                    else // high — user picked one of the candidate exercises for this day
                    {
                        var pickedId = acceptedDays[day.DayId];
                        var candidate = pickedId.HasValue ? day.Candidates.FirstOrDefault(c => c.ExerciseId == pickedId.Value) : null;
                        if (candidate != null)
                            rcDL.AddExerciseToDay(day.DayId, candidate.ExerciseId, targetSets: 3, targetReps: 10);
                    }
                }
                // Every involved day resets + gets a cooldown either way — accepting
                // only some of a bundled group still resolves the WHOLE group, per spec.
                rcDL.SetCooldown(uid, day.DayId, DateTime.Now.AddDays(CooldownDays));
            }

            rcDL.ResolveSuggestion(suggestionId, acceptedDays.Count > 0 ? "accepted" : "declined");
        }

        // ── Turning a suggestion into a natural message + choices ───
        // Deterministic templating, not a Gemini call — keeps viewing a
        // suggestion free (0 model calls), which matters for free-tier users.
        // Gemini only gets involved if the person actually types a follow-up
        // question about it in chat.
        public object BuildSuggestionView(CoachSuggestionModel s)
        {
            var payload = JsonSerializer.Deserialize<SuggestionPayload>(s.Payload) ?? new SuggestionPayload();
            string message;
            var options = new List<object>();

            if (s.Type == "whole_program_fix")
            {
                bool high = payload.Days.Count > 0 && payload.Days[0].Reason == "high";
                var dayNames = string.Join(", ", payload.Days.Select(d => d.DayName));
                message = high
                    ? $"Your last 3 sessions have all landed well over your planned volume, across {dayNames} — looks like the whole program might be light for where you're at. Want me to add an exercise to each day?"
                    : $"Your last 3 sessions have all landed under half your planned volume, across {dayNames} — feels like the current program might be more than fits right now. Want me to trim sets and exercises across the board?";
                options.Add(new { label = high ? "Yes, bulk it up" : "Yes, trim it down", dayIds = payload.Days.Select(d => d.DayId).ToList() });
                options.Add(new { label = "No, leave it", dayIds = new List<int>() });
            }
            else
            {
                var anchor = payload.Days.FirstOrDefault(d => d.IsAnchor) ?? payload.Days.First();
                var bundled = payload.Days.Where(d => !d.IsAnchor).ToList();
                bool high = anchor.Reason == "high";
                string verb = high ? "well over" : "under half of";
                message = bundled.Count > 0
                    ? $"{anchor.DayName} has been running {verb} its planned volume the last couple times" +
                      $" — same story on {string.Join(", ", bundled.Select(b => b.DayName))}. Want me to {(high ? "add something to" : "trim")} {anchor.DayName}, or both?"
                    : $"{anchor.DayName} has been running {verb} its planned volume the last couple times. Want me to {(high ? "add an exercise" : "trim it down")}?";

                options.Add(new { label = $"Fix {anchor.DayName}", dayIds = new List<int> { anchor.DayId } });
                if (bundled.Count > 0)
                    options.Add(new { label = $"Fix {anchor.DayName} + {string.Join(" + ", bundled.Select(b => b.DayName))}", dayIds = payload.Days.Select(d => d.DayId).ToList() });
                options.Add(new { label = "Leave it", dayIds = new List<int>() });
            }

            return new { suggestionId = s.SuggestionId, type = s.Type, message, options, days = payload.Days };
        }

        public void ApplyAddExercise(int dayId, int exerciseId, int targetSets, int targetReps)
            => rcDL.AddExerciseToDay(dayId, exerciseId, targetSets, targetReps);
    }
}
