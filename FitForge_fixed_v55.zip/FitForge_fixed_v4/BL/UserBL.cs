using Microsoft.Extensions.Logging;
using FitForge.DL; using FitForge.Models; using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
namespace FitForge.BL
{
    public class UserBL(UserDL dl, IHttpContextAccessor http, ILogger<UserBL> log)
    {
        public string? ValidateRegistration(string name,string username,string email,string pw,string confirm,double h,double w){
            if(string.IsNullOrWhiteSpace(name))      return "Name is required";
            if(string.IsNullOrWhiteSpace(username))   return "Username is required";
            if(string.IsNullOrWhiteSpace(email)||!email.Contains('@')) return "Valid email required";
            if(pw!=confirm)                           return "Passwords do not match";
            if(pw.Length<8)                           return "Password must be at least 8 characters";
            if(!pw.Any(char.IsUpper))                 return "Password needs an uppercase letter";
            if(!pw.Any(char.IsDigit))                 return "Password needs a number";
            if(h<100||h>250)                          return "Height must be 100–250 cm";
            if(w<30||w>300)                           return "Weight must be 30–300 kg";
            return null;
        }
        public async Task<(bool ok, string msg)> Register(string name,string username,string email,string pw,string confirm,string dob,string gender,double h,double w,string level){
            var err=ValidateRegistration(name,username,email,pw,confirm,h,w);
            if(err!=null)return(false,err);
            try{
                string hash=BCrypt.Net.BCrypt.HashPassword(pw);
                var d=DateTime.TryParse(dob,out var dt)?dt:DateTime.Now.AddYears(-20);
                int uid=dl.RegisterWithProfile(name.Trim(),username.Trim(),email.Trim(),hash,d,gender,(decimal)h,(decimal)w,level);
                await SetSessionAsync(uid,name.Trim());
                return(true,"");
            }catch(Exception ex){
                string msg=ex.Message.Contains("Duplicate",StringComparison.OrdinalIgnoreCase)||ex.Message.Contains("duplicate key",StringComparison.OrdinalIgnoreCase)
                    ?"Username or email already taken":"Registration failed — please try again";
                log.LogError(ex,"Register failed for {U}",username);
                return(false,msg);
            }
        }
        public async Task<(bool ok, string msg)> Login(string username, string password){
            var(user,msg)=dl.Login(username?.Trim()??"",password??"");
            if(user==null)return(false,msg);
            await SetSessionAsync(user.UserId,user.Name);
            return(true,"");
        }
        public void UpdateTheme(int uid,string theme)=>dl.UpdateTheme(uid,theme);
        public void UpdateAccent(int uid,string accent)=>dl.UpdateAccent(uid,accent);
        public void UpdateCoachName(int uid,string name)=>dl.UpdateCoachName(uid,name);
        public void UpdatePlateMathSettings(int uid, bool enabled, string unit)=>dl.UpdatePlateMathSettings(uid, enabled, unit);
        public (bool ok,string msg) UpdatePassword(int uid,string cur,string newPw,string confirm){
            if(newPw!=confirm)return(false,"Passwords do not match");
            if(newPw.Length<8)return(false,"Minimum 8 characters");
            if(!newPw.Any(char.IsUpper))return(false,"Needs an uppercase letter");
            if(!newPw.Any(char.IsDigit))return(false,"Needs a number");
            string r=dl.UpdatePassword(uid,cur,newPw);
            return(r=="Password updated",r);
        }
        public async Task DeleteAccount(int uid){
            dl.DeleteAccount(uid);
            var ctx = http.HttpContext;
            if(ctx!=null){
                ctx.Session.Clear();
                await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            }
        }

        /// <summary>
        /// Marks the user logged in two ways: the existing Session (fast, but wiped on
        /// server restart) and a persistent, sliding-expiration auth cookie (survives
        /// restarts/redeploys since the identity is encrypted directly into the cookie).
        /// </summary>
        private async Task SetSessionAsync(int uid,string name){
            var ctx = http.HttpContext;
            if(ctx==null) return;
            ctx.Session.SetInt32("uid",uid);
            ctx.Session.SetString("uname",name);

            var claims = new List<Claim>{
                new Claim(ClaimTypes.NameIdentifier, uid.ToString()),
                new Claim(ClaimTypes.Name, name)
            };
            var identity  = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties{
                IsPersistent = true,
                ExpiresUtc   = DateTimeOffset.UtcNow.AddDays(60)
            });
        }
    }
}
