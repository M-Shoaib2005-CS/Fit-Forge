using Microsoft.Extensions.Logging;
using System.Linq;
using FitForge.Models; using System.Data;
namespace FitForge.DL
{
    public class UserDL(ILogger<UserDL> log)
    {
        private const int MaxAttempts = 5;
        private const int LockoutMinutes = 15;

        public int Register(string name, string username, string email, string hash){
            log.LogInformation("Registering {Username}",username);
            return Convert.ToInt32(DB.Scalar(
                "INSERT INTO users(name,username,email,password) VALUES(@n,@u,@e,@p); SELECT LAST_INSERT_ID();",
                DB.P("@n",name),DB.P("@u",username.ToLower()),DB.P("@e",email.ToLower()),DB.P("@p",hash)));
        }
        public void CreateProfile(int uid, DateTime dob, string gender, decimal h, decimal w, string level){
            DB.NonQuery("INSERT INTO user_profile(user_id,dob,gender,height_cm,weight_kg,fitness_level) VALUES(@u,@d,@g,@h,@w,@l)",
                DB.P("@u",uid),DB.P("@d",dob.ToString("yyyy-MM-dd")),DB.P("@g",gender),
                DB.P("@h",h),DB.P("@w",w),DB.P("@l",level));
            DB.NonQuery("INSERT INTO user_streaks(user_id) VALUES(@u) ON DUPLICATE KEY UPDATE user_id=user_id",DB.P("@u",uid));
        }

        // Does the users + user_profile + user_streaks inserts as ONE atomic transaction.
        // Without this, a failure partway through (bad enum value, dropped connection, etc.)
        // could leave a orphaned 'users' row with no profile — which then permanently blocks
        // that username/email from ever registering again, since the row itself still exists.
        public int RegisterWithProfile(string name, string username, string email, string hash,
            DateTime dob, string gender, decimal h, decimal w, string level)
        {
            log.LogInformation("Registering {Username}", username);
            return DB.Transaction((c, tx) =>
            {
                using (var cmd = new MySqlConnector.MySqlCommand(
                    "INSERT INTO users(name,username,email,password) VALUES(@n,@u,@e,@p); SELECT LAST_INSERT_ID();", c, tx))
                {
                    cmd.Parameters.Add(DB.P("@n", name));
                    cmd.Parameters.Add(DB.P("@u", username.ToLower()));
                    cmd.Parameters.Add(DB.P("@e", email.ToLower()));
                    cmd.Parameters.Add(DB.P("@p", hash));
                    int uid = Convert.ToInt32(cmd.ExecuteScalar());

                    using (var cmd2 = new MySqlConnector.MySqlCommand(
                        "INSERT INTO user_profile(user_id,dob,gender,height_cm,weight_kg,fitness_level) VALUES(@u,@d,@g,@h,@w,@l)", c, tx))
                    {
                        cmd2.Parameters.Add(DB.P("@u", uid));
                        cmd2.Parameters.Add(DB.P("@d", dob.ToString("yyyy-MM-dd")));
                        cmd2.Parameters.Add(DB.P("@g", gender));
                        cmd2.Parameters.Add(DB.P("@h", h));
                        cmd2.Parameters.Add(DB.P("@w", w));
                        cmd2.Parameters.Add(DB.P("@l", level));
                        cmd2.ExecuteNonQuery();
                    }

                    using (var cmd3 = new MySqlConnector.MySqlCommand(
                        "INSERT INTO user_streaks(user_id) VALUES(@u) ON DUPLICATE KEY UPDATE user_id=user_id", c, tx))
                    {
                        cmd3.Parameters.Add(DB.P("@u", uid));
                        cmd3.ExecuteNonQuery();
                    }

                    return uid;
                }
            });
        }

        public (UserModel? user, string msg) Login(string username, string password){
            try {
                var dt = DB.Select(
                    "SELECT u.*, p.dob, p.gender, p.height_cm, p.weight_kg, p.fitness_level, s.current_streak, s.longest_streak " +
                    "FROM users u LEFT JOIN user_profile p ON u.user_id=p.user_id LEFT JOIN user_streaks s ON u.user_id=s.user_id " +
                    "WHERE u.username=@u", DB.P("@u", username.ToLower()));
                if(dt.Rows.Count==0){log.LogWarning("Login: account not found {U}",username);return(null,"Invalid username or password");}
                var row=dt.Rows[0];

                // Check lockout (only if column exists after migration)
                if(row.Table.Columns.Contains("lockout_until") && row["lockout_until"] != DBNull.Value){
                    var lockout = Convert.ToDateTime(row["lockout_until"]);
                    if(DateTime.UtcNow < lockout){
                        int mins = (int)Math.Ceiling((lockout - DateTime.UtcNow).TotalMinutes);
                        return (null, $"Account locked. Try again in {mins} minute{(mins==1?"":"s")}.");
                    }
                }

                if(!BCrypt.Net.BCrypt.Verify(password, row["password"].ToString()!)){
                    // Increment attempt counter
                    if(row.Table.Columns.Contains("login_attempts")){
                        int attempts = row["login_attempts"] == DBNull.Value ? 0 : Convert.ToInt32(row["login_attempts"]);
                        attempts++;
                        if(attempts >= MaxAttempts){
                            DB.NonQuery("UPDATE users SET login_attempts=@a, lockout_until=@l WHERE user_id=@id",
                                DB.P("@a", attempts),
                                DB.P("@l", DateTime.UtcNow.AddMinutes(LockoutMinutes).ToString("yyyy-MM-dd HH:mm:ss")),
                                DB.P("@id", row["user_id"]));
                            log.LogWarning("Account locked after {N} attempts: {U}", attempts, username);
                            return (null, $"Too many failed attempts. Account locked for {LockoutMinutes} minutes.");
                        }
                        DB.NonQuery("UPDATE users SET login_attempts=@a WHERE user_id=@id",
                            DB.P("@a", attempts), DB.P("@id", row["user_id"]));
                        int remaining = MaxAttempts - attempts;
                        return (null, $"Incorrect password. {remaining} attempt{(remaining==1?"":"s")} remaining.");
                    }
                    return (null,"Invalid username or password");
                }

                // Success — reset attempts
                if(row.Table.Columns.Contains("login_attempts"))
                    DB.NonQuery("UPDATE users SET login_attempts=0, lockout_until=NULL WHERE user_id=@id", DB.P("@id", row["user_id"]));

                log.LogInformation("Login ok: {U}", username);
                return (MapUser(row), "ok");
            } catch(Exception ex){ log.LogError(ex,"Login error {U}",username); return(null,"Login failed"); }
        }

        public UserModel? GetById(int uid){
            var dt=DB.Select(@"SELECT u.*,p.dob,p.gender,p.height_cm,p.weight_kg,p.fitness_level,
                s.current_streak,s.longest_streak FROM users u
                LEFT JOIN user_profile p ON u.user_id=p.user_id
                LEFT JOIN user_streaks s ON u.user_id=s.user_id
                WHERE u.user_id=@id",DB.P("@id",uid));
            return dt.Rows.Count>0?MapUser(dt.Rows[0]):null;
        }
        public void UpdateProfile(int uid, decimal h, decimal w){
            int ex=Convert.ToInt32(DB.Scalar("SELECT COUNT(*) FROM user_profile WHERE user_id=@id",DB.P("@id",uid)));
            if(ex>0) DB.NonQuery("UPDATE user_profile SET height_cm=@h,weight_kg=@w WHERE user_id=@id",DB.P("@h",h),DB.P("@w",w),DB.P("@id",uid));
            else DB.NonQuery("INSERT INTO user_profile(user_id,height_cm,weight_kg) VALUES(@id,@h,@w)",DB.P("@id",uid),DB.P("@h",h),DB.P("@w",w));
        }
        public string UpdatePassword(int uid, string cur, string newPw){
            var h=DB.Scalar("SELECT password FROM users WHERE user_id=@id",DB.P("@id",uid));
            if(h==null||!BCrypt.Net.BCrypt.Verify(cur,h.ToString()!))return "Current password incorrect";
            DB.NonQuery("UPDATE users SET password=@p WHERE user_id=@id",DB.P("@p",BCrypt.Net.BCrypt.HashPassword(newPw)),DB.P("@id",uid));
            return "Password updated";
        }
        public void UpdateTheme(int uid, string theme){
            if(theme!="dark"&&theme!="light")theme="dark";
            DB.NonQuery("UPDATE users SET theme=@t WHERE user_id=@id",DB.P("@t",theme),DB.P("@id",uid));
        }
        public void UpdateAccent(int uid, string accent){
            var valid = new[]{"orange","lime","pink","blue"};
            if(Array.IndexOf(valid,accent)<0)accent="orange";
            DB.NonQuery("UPDATE users SET accent_color=@a WHERE user_id=@id",DB.P("@a",accent),DB.P("@id",uid));
        }
        public void UpdateNotificationPref(int uid, string pref){
            if(pref!="All"&&pref!="WorkoutOnly"&&pref!="Off")pref="All";
            DB.NonQuery("UPDATE users SET notification_pref=@p WHERE user_id=@id",DB.P("@p",pref),DB.P("@id",uid));
        }
        public void UpdateReminderTime(int uid, string hhmm){
            if(!TimeSpan.TryParse(hhmm,out var ts))ts=new TimeSpan(17,0,0);
            DB.NonQuery("UPDATE users SET reminder_time=@t WHERE user_id=@id",DB.P("@t",ts),DB.P("@id",uid));
        }
        public void UpdateCoachName(int uid, string name){
            name = (name ?? "").Trim();
            if(name.Length==0) name="Coach"; // empty input resets to the default rather than storing blank
            if(name.Length>30) name=name.Substring(0,30); // keep it short — it renders in a small header pill
            DB.NonQuery("UPDATE users SET coach_name=@n WHERE user_id=@id",DB.P("@n",name),DB.P("@id",uid));
        }
        public void UpdatePlateMathSettings(int uid, bool enabled, string unit){
            unit = (unit == "lb") ? "lb" : "kg"; // whitelist, never trust raw client input into a stored column
            DB.NonQuery("UPDATE users SET plate_math_enabled=@e, plate_math_unit=@u WHERE user_id=@id",
                DB.P("@e", enabled?1:0), DB.P("@u", unit), DB.P("@id", uid));
        }
        public void UpdateTimezone(int uid, string tz){
            if(string.IsNullOrWhiteSpace(tz))return;
            // Validate it's a real IANA id before storing — a bad/unknown value would
            // otherwise silently break the local-time math later at send time.
            try{ TimeZoneInfo.FindSystemTimeZoneById(tz); }
            catch{ return; }
            try{
                DB.NonQuery("UPDATE users SET timezone=@tz WHERE user_id=@id",DB.P("@tz",tz),DB.P("@id",uid));
            }catch{
                // Timezone accuracy is a nice-to-have for reminder timing — it should never
                // be able to take down the actual subscribe flow (e.g. if a migration step
                // was missed and the column doesn't exist yet). Swallow and move on; the
                // subscription itself still saves fine, reminders just fall back to UTC
                // comparison until this succeeds on a later subscribe/resubscribe.
            }
        }
        public void DeleteAccount(int uid){ log.LogWarning("Deleting account {Uid}",uid); DB.NonQuery("DELETE FROM users WHERE user_id=@id",DB.P("@id",uid)); }
        public void LogWeight(int uid, decimal w, string notes){
            DB.NonQuery("INSERT INTO weight_history(user_id,weight_kg,notes) VALUES(@u,@w,@n)",DB.P("@u",uid),DB.P("@w",w),DB.P("@n",notes));
            DB.NonQuery("UPDATE user_profile SET weight_kg=@w WHERE user_id=@u",DB.P("@w",w),DB.P("@u",uid));
        }
        public List<WeightEntryModel> GetWeightHistory(int uid){
            return DB.Select("SELECT * FROM weight_history WHERE user_id=@u ORDER BY recorded_at DESC LIMIT 30",DB.P("@u",uid))
                .Rows().Select(r=>new WeightEntryModel{
                    WeightId=Convert.ToInt32(r["weight_id"]),WeightKg=Convert.ToDouble(r["weight_kg"]),
                    RecordedAt=Convert.ToDateTime(r["recorded_at"]),Notes=r["notes"]?.ToString()??""}).ToList();
        }
        public int GetWeightLogCount(int uid){
            return Convert.ToInt32(DB.Scalar("SELECT COUNT(*) FROM weight_history WHERE user_id=@u", DB.P("@u",uid)));
        }
        private static UserModel MapUser(DataRow r){
            var u=new UserModel{UserId=Convert.ToInt32(r["user_id"]),Name=r["name"].ToString()!,
                Username=r["username"].ToString()!,Email=r["email"]?.ToString()??"",
                Theme=r.Table.Columns.Contains("theme")&&r["theme"]!=DBNull.Value?r["theme"].ToString()!:"dark"};
            if(r.Table.Columns.Contains("fitness_level")&&r["fitness_level"]!=DBNull.Value) u.FitnessLevel=r["fitness_level"].ToString()!;
            if(r.Table.Columns.Contains("height_cm")&&r["height_cm"]!=DBNull.Value)  u.Height=Convert.ToDouble(r["height_cm"]);
            if(r.Table.Columns.Contains("weight_kg")&&r["weight_kg"]!=DBNull.Value)  u.Weight=Convert.ToDouble(r["weight_kg"]);
            if(r.Table.Columns.Contains("gender")&&r["gender"]!=DBNull.Value)        u.Gender=r["gender"].ToString()!;
            if(r.Table.Columns.Contains("dob")&&r["dob"]!=DBNull.Value){var d=Convert.ToDateTime(r["dob"]);int a=DateTime.Now.Year-d.Year;if(DateTime.Now<d.AddYears(a))a--;u.Age=a;}
            if(r.Table.Columns.Contains("current_streak")&&r["current_streak"]!=DBNull.Value) u.CurrentStreak=Convert.ToInt32(r["current_streak"]);
            if(r.Table.Columns.Contains("longest_streak")&&r["longest_streak"]!=DBNull.Value) u.LongestStreak=Convert.ToInt32(r["longest_streak"]);
            if(r.Table.Columns.Contains("email_verified")&&r["email_verified"]!=DBNull.Value) u.EmailVerified=Convert.ToInt32(r["email_verified"])==1;
            if(r.Table.Columns.Contains("water_goal_ml")&&r["water_goal_ml"]!=DBNull.Value)   u.WaterGoalMl=Convert.ToInt32(r["water_goal_ml"]);
            if(r.Table.Columns.Contains("notification_pref")&&r["notification_pref"]!=DBNull.Value) u.NotificationPref=r["notification_pref"].ToString()!;
            if(r.Table.Columns.Contains("reminder_time")&&r["reminder_time"]!=DBNull.Value){
                // MySqlConnector maps TIME to TimeSpan.
                if(r["reminder_time"] is TimeSpan ts) u.ReminderTime=ts.ToString(@"hh\:mm");
                else if(TimeSpan.TryParse(r["reminder_time"].ToString(),out var ts2)) u.ReminderTime=ts2.ToString(@"hh\:mm");
            }
            if(r.Table.Columns.Contains("timezone")&&r["timezone"]!=DBNull.Value) u.Timezone=r["timezone"].ToString()!;
            if(r.Table.Columns.Contains("coach_name")&&r["coach_name"]!=DBNull.Value&&!string.IsNullOrWhiteSpace(r["coach_name"].ToString())) u.CoachName=r["coach_name"].ToString()!;
            if(r.Table.Columns.Contains("plate_math_enabled")&&r["plate_math_enabled"]!=DBNull.Value) u.PlateMathEnabled=Convert.ToInt32(r["plate_math_enabled"])==1;
            if(r.Table.Columns.Contains("plate_math_unit")&&r["plate_math_unit"]!=DBNull.Value&&!string.IsNullOrWhiteSpace(r["plate_math_unit"].ToString())) u.PlateMathUnit=r["plate_math_unit"].ToString()!;
            if(r.Table.Columns.Contains("accent_color")&&r["accent_color"]!=DBNull.Value&&!string.IsNullOrWhiteSpace(r["accent_color"].ToString())) u.AccentColor=r["accent_color"].ToString()!;
            return u;
        }
    }
}
