-- ============================================================
-- FitForge — Migration: server-synced accent color
-- Run this ONCE against your EXISTING fitforgedb database.
-- Safe to re-run — checks before it changes anything.
-- ============================================================
USE fitforgedb;

SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA='fitforgedb' AND TABLE_NAME='users' AND COLUMN_NAME='accent_color');
SET @sql := IF(@col=0, 'ALTER TABLE users ADD COLUMN accent_color VARCHAR(10) NOT NULL DEFAULT ''orange''', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
